/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/
const container=document.querySelectorAll('section'); // used for catching the sections' titles 
const navTag= document.querySelector('nav'); // used for event delegation
const navUl= document.getElementById('navbar__list'); // used for building the navbar buttons


/**
 * End Global Variables
 * Start Helper Functions
 * 
*/
/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/


// build the nav

let addPutton = function(title, id) // the function used to build the navigation bar ( li & buttons) inside the ul tag
{
    let butElm=document.createElement('button');
    butElm.innerText=title;
    butElm.setAttribute('class','menu__link');
    butElm.setAttribute('id',id);
    
    let navLi = document.createElement("li");
    navLi.setAttribute('class','navbar__menu')
    navLi.setAttribute('id',id)
    navLi.appendChild(butElm);
    return navLi;
}


container.forEach(sect => {let buttonTitle =sect.dataset.nav; //looping over sections and passes arguments of dataset to the addButton function  
                        let buttonId =sect.id;
                        navUl.setAttribute('class','navbar__menu');
                        navUl.appendChild(addPutton(buttonTitle, buttonId));
    
});

// Add class 'active' to section when near top of viewport and button highlighting when scrolling

window.onscroll = function() 
{
    container.forEach(function(sec)
    {
        if (sec.getBoundingClientRect().top >= -450 
        && sec.getBoundingClientRect().top <= 160)
        {
            sec.classList.add('your-active-class');   // Set sections as active
            hightLnav(sec.id, true); //set button highlighting 

        }else
        {
            sec.classList.remove('your-active-class'); //change the active to the current
            hightLnav(sec.id, false); //remove button highlighting
        }
    })
}

function hightLnav(secId, tOrf) //this function highlighting  buttons by section in view
{
   if(tOrf) 
   {
    let liId= 'li '+'#'+secId;
    document.querySelector(liId).classList.add('menu__link_active')
   }else
    {
    let liId= 'li '+'#'+secId;
    document.querySelector(liId).classList.remove('menu__link_active')
    }
}
    /**
 * End Main Functions
 * Begin Events
 * 
*/

// Add the EventListener & check if target is a button
navTag.addEventListener('click',  (evn) => {
    if (evn.target.type === 'submit') // Only buttons run the event's trigger
    {
        evn.preventDefault();
        goToSection(evn.target.id);  
    }

});

// The function Scroll to section ID using scrollIntoView function instead of scrollTo

function goToSection(buttId) 
{
            let secId='section#'+buttId;
            let theSecElem=document.querySelectorAll(secId);  
            theSecElem[0].scrollIntoView({ behavior: 'smooth' });     
}

