# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Folder Hierarchy
landing-page
    css
        - styles.css    
    index.html
    js
        - app.js
    README.md
## discription
The landing page consists of navbar  has auto-generate function depending on the number of sections in the main element, each button clicked will bring the meant section in view also the navbar buttons will be highlighted when scrolling to indicate the section on view, Shadow Effects added to the section in view.  